<?php
//define database name
define('DB_NAME', 'projexx2_ctf');
//access via root user
//TODO - make a seperate user for this program
define('DB_USER', 'root');
//password (super secret), need to move this to config not uploaded
define('DB_PASSWORD', '');
//define host as localhost, connecting to own machine
define('DB_HOST', 'localhost');
//charset is utf8, latin
define('DB_CHARSET', 'utf8');
?>