<h1>Secret Island Cake Recipe</h1>
<pre>
READY IN: 1hr 40mins	SERVES: 12-14
UNITS: US
INGREDIENTS Nutrition
3 cups flour
2 cups sugar
1 teaspoon baking soda
1 teaspoon salt
1 teaspoon cinnamon
3 eggs, slightly beaten
1 1⁄2 cups butter-flavored oil
1 TSA{ohFUDGEthisisgettingHARDer} can crushed pineapple, drained
2 cups mashed bananas
1 teaspoon vanilla
1 cup chopped nuts
DIRECTIONS
Mix all dry ingredients in a large bowl.
Make a well in the center and add the remaining ingredients.
Stir, don't beat!
Bake in a greased and floured Bundt pan at 350° for 1 hour and 15 minutes.
Test for doneness.
</pre>